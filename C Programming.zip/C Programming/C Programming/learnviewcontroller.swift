//
//  learnviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class learnviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    @IBOutlet weak var learn: UILabel!
    
    @IBOutlet weak var quiz: UIButton!
    
    @IBOutlet weak var introductionofcprogramming: UITableViewCell!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func quiz(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Quizviewcontroller") as!
        Quizviewcontroller
        
    self.navigationController?.pushViewController(loginVC, animated: true)
    
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
