//
//  certificationviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class certificationviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    @IBOutlet weak var certificate: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func nextlevel(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
