//
//  ProfileViewController.swift
//  C Programming
//
//  Created by SAIL on 25/10/23.
//

    import UIKit

    class ProfileViewController: UIViewController {

     
        
        @IBOutlet weak var username: UILabel!
        @IBOutlet weak var email: UILabel!
        @IBOutlet weak var points: UILabel!
        var profileModel: Profile!
        override func viewDidLoad() {
            super.viewDidLoad()
            getProfileAPI()
            // Do any additional setup after loading the view.
        }
        
        override func viewWillAppear(_ animated: Bool) {
            
        }
              func getProfileAPI() {
                  APIHandler().getAPIValues(type: Profile.self, apiUrl: ServiceAPI.profileURL, method: "GET") { result in
                      switch result {
                      case .success(let data):
                          self.profileModel = data
                          print(self.profileModel.data ?? "")
                          print(self.profileModel.data?.count ?? 0)
                          DispatchQueue.main.async {
                              if let profile = self.profileModel.data{
                                  self.username.text = profile.first?.username
                                  self.email.text = profile.first?.email
                                  self.points.text = profile.first?.points                          }
                              
                              
                          }
                      case .failure(let error):
                          print(error)
                      }
                  }
    }
    }
