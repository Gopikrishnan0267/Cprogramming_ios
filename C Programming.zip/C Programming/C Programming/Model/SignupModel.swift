//
//  SignupModel.swift
//  javaBoi
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
struct Signup: Codable {
    var status: Bool?
    var message: String?
    var data: [SignupData]?
}

// MARK: - Datum
struct SignupData: Codable {
    var username, email, password: String?
}
