//
//  ProfileModel.swift
//  javaBoi
//
//  Created by SAIL on 17/10/23.
//

import Foundation

// MARK: - Welcome
struct Profile: Codable {
    var data: [ProfileData]?
}

// MARK: - Datum
struct ProfileData: Codable {
    var username, email, points: String?
}
