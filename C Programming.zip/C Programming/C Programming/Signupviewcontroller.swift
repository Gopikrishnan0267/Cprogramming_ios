//
//  Signupviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class Signupviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    
    @IBOutlet weak var welcome: UILabel!
    
    
    @IBOutlet weak var logo: UIImageView!
    
    
    @IBOutlet weak var username: UITextField!
    
    
    @IBOutlet weak var emailid: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    
    @IBOutlet weak var confirmpassword: UITextField!
    
    @IBOutlet weak var signup: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func signupbtn(_ sender: Any) {
            registerUser()
        }

        func registerUser() {
                let formData: [String: String] = [
                    "username": username.text ?? "",
                    "email": emailid.text ?? "",
                    "password": password.text ?? "",
                    "confirmpassword": confirmpassword.text ?? ""
                ]
                APIHandler().postAPIValues(type: Signup.self, apiUrl: ServiceAPI.signupURL, method: "POST", formData: formData) { result in
                    switch result {
                    case .success(let response):
                        print("Status: \(response.status)")
                        print("Message: \(response.message)")
                        DispatchQueue.main.async {
                          let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginviewcontroller") as! loginviewcontroller
                            self.navigationController?.pushViewController(nextVC, animated: true)
                        }
                    case .failure(let error):
                        print("Error: \(error)")
                    }
                }
            }

    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

