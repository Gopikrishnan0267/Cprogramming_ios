//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

public class Constants {
    
    enum serviceType: String {
        case Loginurl = "http://192.168.39.28/c%20api/login.php?"
        case forecasturl = "https://api.openweathermap.org/data/2.5/onecall?lat=33.44&lon=-94.04&appid=4cd569ffb3ecc3bffe9c0587ff02109f"
    }
    
    static let baseUrl: serviceType = .Loginurl
    static let forecast: serviceType = .forecasturl
}
