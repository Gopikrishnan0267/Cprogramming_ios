//
//  levelviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class levelviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    @IBOutlet weak var levels: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func levels(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "topicsviewcontroller") as! topicsviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
