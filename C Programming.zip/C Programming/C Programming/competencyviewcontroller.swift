//
//  competencyviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class competencyviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    
    @IBOutlet weak var competencylevel: UILabel!
    
    
    @IBOutlet weak var Beginnerlevel: UIButton!
    
    @IBOutlet weak var intermediatelevel: UIButton!
    
    @IBOutlet weak var expertlevel: UIButton!
    
    @IBOutlet weak var profile: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profile.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Profile View Controller") as! ProfileViewController
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        // Do any additional setup after loading the view.
    }
    

    @IBAction func Beginner(_ sender: Any) { let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelviewcontroller") as! levelviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func intermediate(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelviewcontroller") as! levelviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
        
    }
    /*
     @IBAction func Expert(_ sender: Any) {
     @IBAction func Expert(_ sender: Any) {
     }
     }
     @IBAction func Expert(_ sender: Any) {
     }
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func Expert(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelviewcontroller") as! levelviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
    
}
}
