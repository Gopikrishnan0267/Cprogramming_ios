//
//  topicsviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class topicsviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    
    @IBOutlet weak var topics: UILabel!
    
    
    @IBOutlet weak var topic1: UIImageView!
    
    @IBOutlet weak var topic2: UIImageView!
    
    @IBOutlet weak var topic3: UIImageView!
    
    @IBOutlet weak var topic4: UIImageView!
    
    @IBOutlet weak var topic5: UIImageView!
  

    
    override func viewDidLoad() {
        super.viewDidLoad()
        topic1.addAction(for: .tap) {
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        
        }
        topic2.addAction(for: .tap) {
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        
        }
         topic3.addAction(for: .tap) {
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
    }
        topic4.addAction(for: .tap) {
           let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
           self.navigationController?.pushViewController(signupVC, animated: true)
   }
        topic5.addAction(for: .tap) {
           let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
           self.navigationController?.pushViewController(signupVC, animated: true)
   }
    
  
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
}
