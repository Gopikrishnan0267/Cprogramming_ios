//
//  loginviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class loginviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    @IBOutlet weak var welcome: UILabel!
    
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var forgetpassword: UIButton!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var createanewaccount: UIButton!
    
    
    var loginModel : Login!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func login(_ sender: Any) {
     
              
              if username.text == "" && password.text == "" {
                  let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
                  alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                  present(alert, animated: true)
              } else {
                  getLoginAPI()
              }
    }
          
    
    @IBAction func CREATEACCOUNT(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Signupviewcontroller") as! Signupviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    func getLoginAPI() {
        

        APIHandler().getAPIValues(type: Login.self, apiUrl: "\(ServiceAPI.loginURL)username=\(username.text  ?? "")&password=\(password.text ?? "")" , method: "GET") { result in
             switch result {
             case .success(let data):
                 self.loginModel = data
                 print(self.loginModel.data ?? "")
                 DispatchQueue.main.async {
                     if self.username.text != self.loginModel.data?.first?.username && self.password.text != self.loginModel.data?.first?.password {
                         let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: UIAlertController.Style.alert)
                         alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                         self.present(alert, animated: true)
                     } else {
                         let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                         let vc = storyboard.instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                         self.navigationController?.pushViewController(vc, animated: true)
                     }
                 }
             case .failure(let error):
                 print(error)
             }
         }
     }
 }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


