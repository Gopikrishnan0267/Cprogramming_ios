//
//  Quizviewcontroller.swift
//  C Programming
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class Quizviewcontroller: UIViewController {

    @IBOutlet weak var topbg: UIView!
    
    @IBOutlet weak var quiz: UILabel!
    
    @IBOutlet weak var time: UIView!
    
    
    @IBOutlet weak var question: UILabel!
    
    @IBOutlet weak var optionA: UILabel!
    
    @IBOutlet weak var optionB: UILabel!
    
    @IBOutlet weak var optionC: UILabel!
    
    @IBOutlet weak var optionD: UILabel!
    
    
    @IBOutlet weak var checkanswer: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
